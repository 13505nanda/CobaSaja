document.getElementById("inCatalogButton").addEventListener("click", function() {
    // Redirect to "show_recommendations.html"
    window.location.href = "show-recommendation";
});

document.getElementById("outsideCatalogButton").addEventListener("click", function() {
    // Redirect to "show_out_recommendations.html"
    window.location.href = "show-out-recommendation";
});
